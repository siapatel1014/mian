# Contributing

Use feature branches when possible and keep the main branch runnable. Do not commit secrets, `.env` files, virtual environments or build artefacts.
