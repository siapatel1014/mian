# Problem Statement — P1

Clinical trials can involve thousands of patient visits across many sites. Protocol deviations such as missed visits, incorrect dosing and banned co-medications may not be identified until late-stage review or audit.

## Audience
- Clinical trial risk managers
- Clinical operations teams
- Site monitors
- Quality and compliance teams

## Why it matters
Late detection increases rework and can jeopardize submission readiness. The supplied industry problem statement highlights that a major trial can have 5,000+ patient visits across 200+ sites and that a rejected submission can create a 6–12 month delay.

## MVP Scope
CliniGuard focuses on early detection from structured visit records:
- compare records against protocol rules
- classify deviation severity
- aggregate risk by site
- produce mitigation/CAPA-ready recommendations
