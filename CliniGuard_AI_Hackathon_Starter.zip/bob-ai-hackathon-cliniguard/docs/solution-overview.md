# Solution Overview

CliniGuard follows an explainable pipeline:

1. Ingest structured visit records.
2. Apply protocol rules for scheduled visits, expected dosing and prohibited co-medications.
3. Produce a deviation reason for each flagged record.
4. Aggregate leading indicators by site.
5. Calculate a 0–100 site risk score.
6. Translate risk signals into targeted CAPA recommendations.
7. Present evidence in an interactive dashboard and downloadable report.

## Differentiation
Instead of showing only a list of deviations, the MVP connects each flag to an explainable reason and then rolls individual events into a site-level operational risk view.

## User Experience
A monitor opens the dashboard, filters sites/severity, reviews the risk ranking, drills into flagged visits, and downloads a CAPA-ready JSON report.
