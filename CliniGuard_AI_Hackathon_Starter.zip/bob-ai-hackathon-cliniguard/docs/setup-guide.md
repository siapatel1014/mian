# Setup Guide

## Prerequisites
- Python 3.11 or newer
- Git
- GitHub account
- IBM Bob account/installation for the hackathon workflow

## Install
```bash
git clone <YOUR_REPOSITORY_URL>
cd bob-ai-hackathon-<YOUR_TEAM_NAME>
cd src
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Then:
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Verify
1. Streamlit starts without errors.
2. Dashboard shows records reviewed.
3. Site risk table appears.
4. Protocol deviation table contains flagged records.
5. Selecting a site produces a CAPA report.
6. CAPA report downloads successfully.

## Troubleshooting

| Error | Fix |
|---|---|
| `streamlit is not recognized` | Activate `.venv` and run `pip install -r requirements.txt` |
| `ModuleNotFoundError` | Run commands from `src/` with the virtual environment active |
| Blank dashboard | Restart Streamlit and check terminal traceback |
| GitHub Action fails | Open GitHub → Actions → Validate Submission and fix the reported field/file |
