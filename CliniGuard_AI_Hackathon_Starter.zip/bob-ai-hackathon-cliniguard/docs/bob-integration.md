# IBM Bob Integration & Development Evidence

IBM Bob is used as the AI coding agent for the project. The project workflow uses Bob for:

1. Planning the architecture before implementation.
2. Generating/refining the protocol-rule engine.
3. Reviewing source code and identifying edge cases.
4. Running terminal commands for tests and the Streamlit application.
5. Creating/refining architecture documentation.

## Suggested Bob prompts used during development

### Plan
> Analyze this clinical trial monitoring MVP. Propose a modular architecture for protocol deviation detection, site risk scoring and CAPA report generation. Keep all patient data synthetic.

### Implement
> Implement the protocol rule engine described in docs/problem-statement.md. Every detected deviation must include an explainable reason and a severity.

### Review
> Review src/engine.py for correctness, explainability and edge cases. Suggest fixes without changing the public interface.

### Test
> Run the application and check that the dashboard starts, deviation records are generated, site risk scores are produced and CAPA JSON can be downloaded.

## Evidence to capture for the final submission
- Screenshot of Bob planning the architecture.
- Screenshot of Bob implementing/reviewing a feature in this repository.
- Screenshot of the running CliniGuard dashboard.
- Demo video showing the complete user journey.

The supplied Bob guide describes Agent mode for editing/writing code, Ask mode for Q&A, Plan mode for planning, Bob Shell for terminal tasks, and MCP for external tools/data. Use those capabilities as appropriate.
