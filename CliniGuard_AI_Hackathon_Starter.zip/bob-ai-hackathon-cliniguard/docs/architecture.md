# Architecture

```mermaid
flowchart TD
    A[Clinical Trial Visit Records] --> B[Protocol Rule Engine]
    B --> C[Deviation Classifier]
    C --> D[Site Risk Scoring]
    D --> E[CAPA Recommendation Engine]
    C --> F[Streamlit Dashboard]
    D --> F
    E --> G[Downloadable CAPA Report]
    F --> G
```

| Component | Technology | Responsibility |
|---|---|---|
| Data generator | Python/Pandas | Synthetic demo records |
| Rule engine | Python | Protocol comparison |
| Classifier | Python | Major/Minor/Administrative |
| Risk engine | Python | Site risk score |
| UI | Streamlit | Monitoring dashboard |
| Reporting | JSON | CAPA-ready output |
| AI engineering | IBM Bob | Planning, implementation, review and development workflow |

## Security / Scalability
The demo contains synthetic data only. A production implementation should add identity/access control, encryption, audit logging, PHI/PII controls, validated data pipelines, model governance and site-level permissions.
