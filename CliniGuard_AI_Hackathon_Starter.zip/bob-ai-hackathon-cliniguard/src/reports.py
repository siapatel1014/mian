from __future__ import annotations
import json
import pandas as pd
from engine import recommend_capa

def build_capa_report(site_id: str, site_row: pd.Series, deviations: pd.DataFrame) -> str:
    site_devs = deviations[(deviations.site_id == site_id) & (deviations.deviation_types != "")]
    actions = recommend_capa(site_row)

    payload = {
        "site_id": site_id,
        "risk_score": float(site_row["risk_score"]),
        "risk_level": site_row["risk_level"],
        "records_reviewed": int(site_row["records_reviewed"]),
        "major_deviations": int(site_row["major_deviations"]),
        "minor_deviations": int(site_row["minor_deviations"]),
        "recommended_mitigations": actions,
        "flagged_visits": site_devs[["visit_id","subject_id","visit_date","deviation_types","severity","reason"]].to_dict("records")
    }
    return json.dumps(payload, indent=2)
