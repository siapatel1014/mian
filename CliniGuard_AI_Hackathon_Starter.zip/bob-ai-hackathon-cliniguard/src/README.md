# Source Layout

- `app.py` — Streamlit dashboard
- `engine.py` — protocol rules, deviation detection, severity and site-risk scoring
- `data_generator.py` — synthetic demo dataset
- `reports.py` — CAPA-ready report generation
- `.env.example` — environment variable template
