# Presentation

Create `slides.pdf` or `slides.pptx`.

Recommended order:
1. Problem
2. Solution
3. Demo / architecture
4. IBM Bob integration
5. Impact / future scope
