Add real screenshots after running the app. Required: 01-home-dashboard.png, 02-query-input.png, 03-result-output.png
