# Demo

Add:
- `demo-video-link.txt` — real 3–5 minute demo URL
- `live-demo-url.txt` — deployment URL or `NOT DEPLOYED`
- `screenshots/` — at least 3 screenshots of the running app
